from principal.models import Alumno, Profesor, Curso, Matricula, Dictar, Nota
from django.contrib import admin

admin.site.register(Alumno)
admin.site.register(Profesor)
admin.site.register(Curso)
admin.site.register(Matricula)
admin.site.register(Dictar)
admin.site.register(Nota)